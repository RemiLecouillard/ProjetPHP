<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /ifs.ftp//ws-homes/public_html/ProjetPHP was not found on this server.</p>
<hr>
<address>Apache/2.4.10 (Debian) Server at www.iutcaen.unicaen.fr Port 80</address>
</body></html>
